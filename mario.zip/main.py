from Core import Core

if __name__ == '__main__':
    oCore = Core()
    oCore.main_loop()
